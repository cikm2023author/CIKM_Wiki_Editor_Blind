Each line is an example which corresponds to the location of an edit on a Wikipedia page.
An edit is performed by a user, and consists of pre-edit text and post-edit text.
Each line contains the following fields:

user -
    The username of the editor responsible for making the changes from the pre-edit text
    to the post-edit text.

revision_number -
    Wikipedia's unique identifier of the version of the page as produced by the user. To view
    this version, go to
    https://en.wikipedia.org/w/index.php?title=[ARTICLE_TITLE]&oldid=[REVISION_NUMBER]

parent_user -
    The username of the editor responsible for the previous version of the page.
    This user need not be the actual author of the parent_text.

parent_revision_number -
    Wikipedia's unique identifier of the previous version of the page.

article_title -
    The title of the Wikipedia article.

revision_text -
    The post-edit text, which contains the text from a single location of the article where the
    user edited text.

parent_text - 
    The pre-edit text, which contains the text from the same location of the article before the
    user edited text.
